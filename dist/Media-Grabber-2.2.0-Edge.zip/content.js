let latestTranscript = "";

function getMediaUrl(mediaElement) {
  return mediaElement.currentSrc || mediaElement.src || mediaElement.querySelector("source")?.src || "";
}

function sendMediaAction(type, mediaElement) {
  const url = getMediaUrl(mediaElement);
  if (!url) {
    showTranscriptBox("Geen directe media-URL gevonden. Start de speler en probeer opnieuw.");
    return;
  }

  if (type === "TRANSCRIBE_MEDIA" && url.startsWith("blob:")) {
    showTranscriptBox("Deze speler gebruikt een tijdelijke blob-stream. Transcriptie werkt alleen met een directe HTTP(S)-media-URL.");
    return;
  }

  if (type === "TRANSCRIBE_MEDIA") {
    latestTranscript = "";
    showTranscriptBox("Audio wordt opgehaald en getranscribeerd...");
  }

  chrome.runtime.sendMessage({ type, url })
    .then((result) => {
      if (!result?.ok) {
        showTranscriptBox(`Fout: ${result?.error || "De actie is mislukt."}`);
      } else if (type === "TRANSCRIBE_MEDIA") {
        latestTranscript = result.text || "";
        showTranscriptBox(latestTranscript || "Er is geen transcript ontvangen.");
      }
    })
    .catch((error) => showTranscriptBox(`Fout: ${error.message}`));
}

function styleButton(button, backgroundColor) {
  Object.assign(button.style, {
    background: backgroundColor,
    color: "#ffffff",
    border: "none",
    padding: "5px 10px",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "11px",
    fontWeight: "bold",
    fontFamily: "system-ui, sans-serif"
  });
}

function makeDraggable(element, handle, onStartDrag = () => {}) {
  handle.style.cursor = "grab";
  handle.style.touchAction = "none";
  handle.style.userSelect = "none";
  handle.title = "Sleep om te verplaatsen";

  handle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.target.closest("button")) return;
    event.preventDefault();
    event.stopPropagation();

    const startRect = element.getBoundingClientRect();
    const startX = event.clientX;
    const startY = event.clientY;
    let hasStartedDragging = false;
    handle.style.cursor = "grabbing";
    handle.setPointerCapture(event.pointerId);

    const move = (moveEvent) => {
      if (!hasStartedDragging) {
        hasStartedDragging = true;
        onStartDrag(startRect);
      }
      element.style.left = `${startRect.left + moveEvent.clientX - startX}px`;
      element.style.top = `${startRect.top + moveEvent.clientY - startY}px`;
      element.style.right = "auto";
      element.style.bottom = "auto";
    };

    const stop = () => {
      handle.style.cursor = "grab";
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", stop);
      handle.removeEventListener("pointercancel", stop);
    };

    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", stop);
    handle.addEventListener("pointercancel", stop);
  });
}

function attachButtonsToMedia(mediaElement) {
  if (mediaElement.dataset.grabberAttached) return;
  const parent = mediaElement.parentElement;
  if (!parent) return;

  mediaElement.dataset.grabberAttached = "true";
  if (window.getComputedStyle(parent).position === "static") {
    parent.style.position = "relative";
  }

  const overlay = document.createElement("div");
  overlay.className = "media-grabber-overlay";
  Object.assign(overlay.style, {
    position: "absolute",
    top: "10px",
    right: "10px",
    zIndex: "2147483647",
    display: "flex",
    gap: "6px",
    background: "rgba(15, 23, 42, 0.9)",
    padding: "6px 8px",
    borderRadius: "6px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.4)"
  });
  overlay.dataset.grabberDefaultDisplay = "flex";
  if (document.documentElement.dataset.mediaGrabberHidden === "true") {
    overlay.style.setProperty("display", "none", "important");
  }
  overlay._grabberParent = parent;

  const dragHandle = document.createElement("span");
  dragHandle.textContent = "Verplaats";
  Object.assign(dragHandle.style, {
    alignSelf: "center",
    color: "#d1d5db",
    fontSize: "10px",
    fontFamily: "system-ui, sans-serif"
  });

  const downloadButton = document.createElement("button");
  downloadButton.type = "button";
  downloadButton.textContent = "Download";
  styleButton(downloadButton, "#2563eb");
  downloadButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    sendMediaAction("DOWNLOAD_MEDIA", mediaElement);
  });

  const transcribeButton = document.createElement("button");
  transcribeButton.type = "button";
  transcribeButton.textContent = "Transcript";
  styleButton(transcribeButton, "#15803d");
  transcribeButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    sendMediaAction("TRANSCRIBE_MEDIA", mediaElement);
  });

  overlay.append(dragHandle, downloadButton, transcribeButton);
  makeDraggable(overlay, dragHandle, (rect) => {
    document.documentElement.appendChild(overlay);
    overlay.style.position = "fixed";
    overlay.style.left = `${rect.left}px`;
    overlay.style.top = `${rect.top}px`;
    overlay.style.right = "auto";
    overlay.style.bottom = "auto";
    overlay.dataset.grabberMoved = "true";
  });
  parent.appendChild(overlay);
}

function scanForMedia() {
  const mediaList = [...document.querySelectorAll("video, audio")];
  mediaList.forEach(attachButtonsToMedia);
  return mediaList.length;
}

async function analyzePracticeQuestion() {
  const answerButton = document.querySelector("[data-practice-answer]");
  const answerContent = document.querySelector("[data-practice-result]");
  if (!latestTranscript) {
    answerContent.textContent = "Maak eerst een transcriptie van de uitleg.";
    answerContent.style.display = "block";
    return;
  }

  const pageText = document.body?.innerText?.trim().slice(-18000) || "";
  if (!pageText) {
    answerContent.textContent = "Ik kan geen zichtbare vraag of antwoordopties op deze pagina vinden.";
    answerContent.style.display = "block";
    return;
  }

  answerButton.disabled = true;
  answerButton.textContent = "Oefenvraag analyseren...";
  answerContent.textContent = "Vraag en antwoordopties vergelijken met de transcriptie...";
  answerContent.style.display = "block";

  try {
    const result = await chrome.runtime.sendMessage({
      type: "ANSWER_PRACTICE_QUESTION",
      pageText,
      transcript: latestTranscript.slice(0, 30000)
    });
    if (!result?.ok) throw new Error(result?.error || "De analyse is mislukt.");
    answerContent.textContent = result.answer;
  } catch (error) {
    answerContent.textContent = `Fout bij analyseren: ${error.message}`;
  } finally {
    answerButton.disabled = false;
    answerButton.textContent = "Beantwoord oefenvraag";
  }
}

function showTranscriptBox(text) {
  let box = document.getElementById("ai-transcript-box");
  if (!box) {
    box = document.createElement("div");
    box.id = "ai-transcript-box";
    Object.assign(box.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      width: "min(360px, calc(100vw - 40px))",
      maxHeight: "40vh",
      overflowY: "auto",
      whiteSpace: "pre-wrap",
      overflowWrap: "anywhere",
      background: "#1e1e2e",
      color: "#cdd6f4",
      padding: "14px",
      borderRadius: "8px",
      boxShadow: "0 10px 25px rgba(0,0,0,0.5)",
      zIndex: "2147483647",
      fontFamily: "system-ui, sans-serif",
      fontSize: "13px",
      lineHeight: "1.5",
      border: "1px solid #45475a"
    });
    box.dataset.grabberDefaultDisplay = "block";
    if (document.documentElement.dataset.mediaGrabberHidden === "true") {
      box.style.setProperty("display", "none", "important");
    }

    const header = document.createElement("div");
    Object.assign(header.style, {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "12px",
      marginBottom: "8px",
      paddingBottom: "8px",
      borderBottom: "1px solid #45475a"
    });

    const title = document.createElement("strong");
    title.textContent = "Transcript";
    header.appendChild(title);

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "Sluiten";
    closeButton.style.cssText = "cursor:pointer";
    closeButton.addEventListener("click", () => box.remove());
    header.appendChild(closeButton);
    box.appendChild(header);
    makeDraggable(box, header);

    const content = document.createElement("div");
    content.dataset.transcriptContent = "true";
    box.appendChild(content);

    const answerButton = document.createElement("button");
    answerButton.type = "button";
    answerButton.dataset.practiceAnswer = "true";
    answerButton.textContent = "Beantwoord oefenvraag";
    styleButton(answerButton, "#a16207");
    answerButton.style.width = "100%";
    answerButton.style.marginTop = "12px";
    answerButton.addEventListener("click", analyzePracticeQuestion);
    box.appendChild(answerButton);

    const answerContent = document.createElement("div");
    answerContent.dataset.practiceResult = "true";
    Object.assign(answerContent.style, {
      display: "none",
      marginTop: "10px",
      paddingTop: "10px",
      borderTop: "1px solid #45475a"
    });
    box.appendChild(answerContent);
    document.body.appendChild(box);
  }

  box.querySelector("[data-transcript-content]").textContent = text;
  const answerButton = box.querySelector("[data-practice-answer]");
  answerButton.style.display = latestTranscript ? "block" : "none";
  const answerContent = box.querySelector("[data-practice-result]");
  answerContent.textContent = "";
  answerContent.style.display = "none";
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "SCAN_MEDIA") {
    sendResponse({ count: scanForMedia() });
  } else if (message?.type === "RESET_OVERLAYS") {
    document.querySelectorAll(".media-grabber-overlay").forEach((overlay) => {
      const parent = overlay._grabberParent;
      if (parent?.isConnected) parent.appendChild(overlay);
      else overlay.remove();
      Object.assign(overlay.style, {
        position: "absolute",
        left: "",
        top: "10px",
        right: "10px",
        bottom: ""
      });
      delete overlay.dataset.grabberMoved;
    });

    const transcriptBox = document.getElementById("ai-transcript-box");
    if (transcriptBox) {
      Object.assign(transcriptBox.style, {
        position: "fixed",
        left: "",
        top: "",
        right: "20px",
        bottom: "20px"
      });
    }
    sendResponse({ ok: true });
  }
});

scanForMedia();
new MutationObserver((mutations) => {
  if (mutations.some((mutation) => mutation.addedNodes.length)) scanForMedia();
}).observe(document.documentElement, { childList: true, subtree: true });