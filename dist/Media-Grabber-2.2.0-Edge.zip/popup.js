const status = document.getElementById("status");
const scanButton = document.getElementById("scanBtn");
const resetButton = document.getElementById("resetBtn");
const saveKeyButton = document.getElementById("saveKeyBtn");
const apiKeyInput = document.getElementById("apiKey");

chrome.storage.local.get("groqApiKey").then(({ groqApiKey }) => {
  if (groqApiKey) apiKeyInput.placeholder = "Sleutel opgeslagen; voer in om te vervangen";
});

scanButton.addEventListener("click", async () => {
  scanButton.disabled = true;
  status.textContent = "Pagina scannen...";

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("Geen actieve browsertab gevonden.");
    const result = await chrome.tabs.sendMessage(tab.id, { type: "SCAN_MEDIA" });
    status.textContent = result.count
      ? `${result.count} media-element(en) gevonden.`
      : "Geen video- of audio-elementen gevonden.";
  } catch (error) {
    status.textContent = `Scannen niet mogelijk: ${error.message}`;
  } finally {
    scanButton.disabled = false;
  }
});

resetButton.addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("Geen actieve browsertab gevonden.");
    await chrome.tabs.sendMessage(tab.id, { type: "RESET_OVERLAYS" });
    status.textContent = "Vensters teruggezet.";
  } catch (error) {
    status.textContent = `Terugzetten niet mogelijk: ${error.message}`;
  }
});

saveKeyButton.addEventListener("click", async () => {
  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) {
    status.textContent = "Vul eerst je Groq API-sleutel in.";
    return;
  }

  await chrome.storage.local.set({ groqApiKey: apiKey });
  apiKeyInput.value = "";
  apiKeyInput.placeholder = "Sleutel opgeslagen; voer in om te vervangen";
  status.textContent = "API-sleutel lokaal opgeslagen.";
});